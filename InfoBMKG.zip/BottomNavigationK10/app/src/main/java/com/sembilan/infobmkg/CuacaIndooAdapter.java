package com.sembilan.infobmkg;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

public class CuacaIndooAdapter extends RecyclerView.Adapter<CuacaIndooAdapter.ViewHolder> {

    private Context context;
    private List<CuacaDaerahh> list;

    public CuacaIndooAdapter(Context context, List<CuacaDaerahh> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_cuacad, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final CuacaDaerahh obj = list.get(position);
        holder.Kota.setText("Kota : "+obj.getKota());
        holder.Pagi.setText("Pagi : "+obj.getPagi());
        holder.Siang.setText("Siang : "+obj.getSiang());
        holder.Malam.setText("Malam : "+obj.getMalam());
        holder.Dini_Hari.setText("Dini Hari : "+obj.getDini_Hari());
        holder.Suhu.setText("Suhu : "+obj.getSuhu());
        holder.Kelembaban.setText("Kelembaban : "+obj.getKelembaban());


        holder.box_linear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ListCuacadActivity.class);
                intent.putExtra("infocuacadaerah", obj.getInfoCuacaDaerahh());
                intent.putExtra("Kota", obj.getKota());
                intent.putExtra("Pagi", obj.getPagi());
                intent.putExtra("Siang", obj.getSiang());
                intent.putExtra("Malam", obj.getMalam());
                intent.putExtra("Dini Hari", obj.getDini_Hari());
                intent.putExtra("Suhu", obj.getSuhu());
                intent.putExtra("Kelembaban", obj.getKelembaban());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView Kota;
        private TextView Pagi;
        private TextView Siang;
        private TextView Malam;
        private TextView Dini_Hari;
        private TextView Suhu;
        private TextView Kelembaban;
        private LinearLayout box_linear;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            Kota = itemView.findViewById(R.id.kota);
            Pagi = itemView.findViewById(R.id.pagi);
            Siang = itemView.findViewById(R.id.siang);
            Malam = itemView.findViewById(R.id.malam);
            Dini_Hari = itemView.findViewById(R.id.dini_hari);
            Suhu = itemView.findViewById(R.id.suhu);
            Kelembaban = itemView.findViewById(R.id.kelembaban);
            box_linear = itemView.findViewById(R.id.box_linear);
        }
    }
}
