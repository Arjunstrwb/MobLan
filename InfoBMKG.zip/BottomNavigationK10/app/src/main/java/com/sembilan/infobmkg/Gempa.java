package com.sembilan.infobmkg;

import java.io.DataInput;
import java.io.Serializable;
public class Gempa implements Serializable {
    private String Status;
    private String Tanggal;
    private String Jam;
    private String Lintang;
    private String Bujur;
    private String Kedalaman;
    private String M;
    private String MT;
    private String Region;

    public Gempa() {
    }

    public Gempa(String Status, String Tanggal, String Jam, String Lintang, String Bujur, String Kedalaman, String M, String MT, String Region){
        this.Status = Status;
        this.Tanggal = Tanggal;
        this.Jam = Jam;
        this.Lintang = Lintang;
        this.Bujur = Bujur;
        this.Kedalaman = Kedalaman;
        this.M = M;
        this.MT = MT;
        this.Region = Region;

    }

    public String getStatus() { return Status; }

    public void setStatus(String Status) { this.Status = Status; }

    public  String getTanggal() { return Tanggal; }

    public void setTanggal(String Tanggal) { this.Tanggal = Tanggal; }

    public String getJam() { return  Jam; }

    public void setJam(String jam) { this.Jam = Jam; }

    public String getLintang() { return Lintang; }

    public void setLintang(String Lintang) { this.Lintang = Lintang; }

    public String getBujur() { return Bujur; }

    public void setBujur(String Bujur) { this.Bujur = Bujur; }

    public String getKedalaman() { return Kedalaman; }

    public void setKedalaman(String Kedalaman) { this.Kedalaman = Kedalaman; }

    public String getM() { return M; }

    public void setM(String M) { this.M = M; }

    public String getMT() { return  MT; }

    public void setMT(String MT) { this.MT = MT; }

    public String getRegion() { return  Region; }

    public void setRegion(String Region) { this.Region = Region; }

}
