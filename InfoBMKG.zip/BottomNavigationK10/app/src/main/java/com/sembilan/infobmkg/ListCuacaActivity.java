package com.sembilan.infobmkg;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;


public class ListCuacaActivity extends AppCompatActivity {
    private ActionBar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_cuacad);

        Intent intent = getIntent();
        String Kota = intent.getStringExtra("Kota");
        String Malam = intent.getStringExtra("Malam");
        String Dini_Hari = intent.getStringExtra("Dini Hari");
        String Suhu = intent.getStringExtra("Suhu");
        String Kelembaban = intent.getStringExtra("Kelembaban");

        toolbar = getSupportActionBar();
        toolbar.setTitle("Kota : " + Kota);
        toolbar.setSubtitle("Suhu : " +Suhu);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }
}
