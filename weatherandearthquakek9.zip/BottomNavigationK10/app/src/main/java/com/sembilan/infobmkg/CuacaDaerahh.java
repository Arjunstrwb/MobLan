package com.sembilan.infobmkg;

public class CuacaDaerahh {
    private String infoCuacaDaerahh;
    private String Kota;
    private String Pagi;
    private String Siang;
    private String Malam;
    private String Dini_Hari;
    private String Suhu;
    private String Kelembaban;

    public CuacaDaerahh() {}

    public CuacaDaerahh(String Kota, String Pagi, String Siang, String Malam, String Dini_Hari, String Suhu, String Kelembaban) {
        this.Kota = Kota;
        this.Pagi = Pagi;
        this.Siang = Siang;
        this.Malam = Malam;
        this.Dini_Hari = Dini_Hari;
        this.Suhu = Suhu;
        this.Kelembaban = Kelembaban;
    }

    public String getKota() { return Kota; }

    public void setKota(String Kota) {this.Kota = Kota; }

    public String getPagi() { return  Pagi; }

    public void setPagi(String Pagi) {this.Pagi = Pagi; }

    public String getSiang() { return Siang; }

    public void setSiang(String Siang) {this.Siang = Siang; }

    public String getMalam() { return Malam; }

    public void setMalam(String Malam) {this.Malam = Malam;}

    public String getDini_Hari() { return Dini_Hari; }

    public void setDini_Hari(String Dini_Hari) {this.Dini_Hari = Dini_Hari; }

    public String getSuhu() { return Suhu;}

    public void setSuhu(String Suhu) {this.Suhu = Suhu;}

    public String getKelembaban() { return Kelembaban;}

    public void setKelembaban(String Kelembaban) { this.Kelembaban = Kelembaban;}

    public String getInfoCuacaDaerahh() {
        return infoCuacaDaerahh;

    }

    public void setInfoCuacaDaerahh(String CuacaDaerahh) {
        this.infoCuacaDaerahh = infoCuacaDaerahh;
    }
    }

