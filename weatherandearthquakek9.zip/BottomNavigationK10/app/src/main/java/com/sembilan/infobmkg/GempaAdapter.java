package com.sembilan.infobmkg;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

public class GempaAdapter extends RecyclerView.Adapter<GempaAdapter.ViewHolder> {

    private Context context;
    private List<Gempaa> list;

    public GempaAdapter(Context context, List<Gempaa> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_gempa, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Gempaa obj = list.get(position);
        holder.status.setText("Status : "+obj.getStatus());
        holder.tanggal.setText("Tanggal : "+obj.getTanggal());
        holder.jam.setText("Jam :"+obj.getJam());
        holder.lintang.setText("Lintang : "+obj.getLintang());
        holder.bujur.setText("Bujur : "+obj.getBujur());
        holder.kedalaman.setText("Kedalaman : "+obj.getKedalaman());
        holder.m.setText("M : "+obj.getM());
        holder.mt.setText("MT : "+obj.getMT());
        holder.region.setText("Region : "+obj.getRegion());



        holder.box_linear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ListGempaActivity.class);
                intent.putExtra("infogempa", obj.getInfoGempaa());
                intent.putExtra("Status", obj.getStatus());
                intent.putExtra("Tanggal", obj.getTanggal());
                intent.putExtra("Jam", obj.getJam());
                intent.putExtra("Lintang", obj.getLintang());
                intent.putExtra("Bujur", obj.getBujur());
                intent.putExtra("Kedalaman", obj.getKedalaman());
                intent.putExtra("M", obj.getM());
                intent.putExtra("MT", obj.getMT());
                intent.putExtra("Region", obj.getRegion());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView status;
        private TextView tanggal;
        private TextView jam;
        private TextView lintang;
        private TextView bujur;
        private TextView kedalaman;
        private TextView m;
        private TextView mt;
        private TextView region;
        private LinearLayout box_linear;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            status = itemView.findViewById(R.id.status);
            tanggal = itemView.findViewById(R.id.tanggal);
            jam = itemView.findViewById(R.id.jamutc);
            lintang = itemView.findViewById(R.id.lintang);
            bujur = itemView.findViewById(R.id.bujur);
            kedalaman = itemView.findViewById(R.id.kedalaman);
            m = itemView.findViewById(R.id.m);
            mt = itemView.findViewById(R.id.mt);
            region = itemView.findViewById(R.id.region);
            box_linear = itemView.findViewById(R.id.box_linear);
        }
    }
}
