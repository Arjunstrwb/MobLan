package com.sembilan.infobmkg;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;


public class ListGempaActivity extends AppCompatActivity {
    private ActionBar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_gempa);

        Intent intent = getIntent();
        String Region = intent.getStringExtra("Region");
        String Status = intent.getStringExtra("Status");
        String Tanggal = intent.getStringExtra("Tanggal");
        String Jam = intent.getStringExtra("Jam (UTC)");
        String Lintang = intent.getStringExtra("Lintang");
        String Bujur = intent.getStringExtra("Bujur");
        String Kedalaman = intent.getStringExtra("Kedalaman");
        String M = intent.getStringExtra("M");
        String MT = intent.getStringExtra("MT");

        toolbar = getSupportActionBar();
        toolbar.setTitle("Wilayah : " + Region);
        toolbar.setSubtitle("Tanggal Terjadi : " +Tanggal);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }
}
